export enum MailTrigger {
    VERIFY_EMAIL = 1,
    // Add PascalCase alias used across the codebase
    VerifyEmail = VERIFY_EMAIL,
}