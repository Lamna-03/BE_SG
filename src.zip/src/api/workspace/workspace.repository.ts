import { AppDataSource } from "../../configs/typeorm.config";
import { Workspace } from "../../common/entities/Workspace.entity";

export class WorkspaceRepository {
    private repository = AppDataSource.getRepository(Workspace);

    async findAll():Promise<Workspace[]> {
        return this.repository.find({
            relations: ["owner", "members","boards"],
        });
    }

    async findById(id: string):Promise<Workspace | null> {
        return this.repository.findOne({
            where: { id },
            relations: ["owner", "members","boards"],
        });
    }

    async createWorkspace(WorkspaceData: Partial<Workspace>):Promise<Workspace> {
        const workspace = this.repository.create(WorkspaceData);
        return this.repository.save(workspace);
    }

    async updateWorkspace(id: string, WorkspaceData: Partial<Workspace>):Promise<Workspace | null> {
        const workspace = await this.repository.findOneBy({ id });
        if (!workspace) return null;
        this.repository.merge(workspace, WorkspaceData);
        return this.repository.save(workspace);
    }

    async deleteWorkspace(id: string):Promise<boolean> {
        const result = await this.repository.delete(id);
        return result.affected !== 0;
    }

}