import { Workspace } from "./schemas/workspaceSchema";
import { ServiceResponse , ResponseStatus } from "../../common/models/serviceResponse";
import { StatusCodes } from "http-status-codes";
import { WorkspaceRepository } from "./workspace.repository";

export class WorkspaceService {
    constructor(private workspaceRepository = new WorkspaceRepository()) {}

    async create(workspaceData: Workspace): Promise<ServiceResponse<Workspace | null>> {
        try {
            const newWorkspace = await this.workspaceRepository.create(workspaceData);
            if (!newWorkspace) {
                return new ServiceResponse(
                    ResponseStatus.FAIL,
                    "Error creating workspace",
                    null,
                    StatusCodes.INTERNAL_SERVER_ERROR
                );  
            }
            return new ServiceResponse<Workspace>(
                ResponseStatus.SUCCESS,
                "Workspace created successfully",
                newWorkspace,
                StatusCodes.CREATED
            );
        } catch (error) {
            return new ServiceResponse(
                ResponseStatus.FAIL,
                "Error creating workspace",
                null,
                StatusCodes.INTERNAL_SERVER_ERROR
            );
        }
    }

    async getAll(userID: string): Promise<ServiceResponse<Workspace[] | null>> {
         
            
    }
}